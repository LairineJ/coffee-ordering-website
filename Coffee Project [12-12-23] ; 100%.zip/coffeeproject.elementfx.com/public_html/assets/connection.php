<?php
$conn  = mysqli_connect('localhost','itoouzkq_dailydrip','1234','itoouzkq_dailydrip');
if(mysqli_connect_errno())
{
    echo 'Database Connection Error';
}
?>