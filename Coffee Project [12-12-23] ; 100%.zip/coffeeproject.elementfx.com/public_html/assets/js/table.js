$(document).ready(function () {
    new DataTable('.table');
  });